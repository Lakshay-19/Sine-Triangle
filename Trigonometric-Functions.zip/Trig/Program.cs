﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Lakshay Punj
//March 18, 2019
//Trig calculations

namespace Trig
{
    class Program
    {
        static void Main(string[] args)
        {
            //User inputs oppoaite and hypotenuse sides
            Console.WriteLine("Enter the opposite side");
            double SideOpp = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the hypotenuse side");
            double SideHyp = double.Parse(Console.ReadLine());

            //Calculate angle

            double Angle = Math.Sin(SideOpp / SideHyp);
            Angle = Angle * 180 / Math.PI;

            //Read input in angle degrees to radian

            Angle = Angle * Math.PI / 180;

            //Calculation output

            Console.WriteLine("The sin of the angle = " + Angle);

            Console.ReadKey();




        }
    }
}
